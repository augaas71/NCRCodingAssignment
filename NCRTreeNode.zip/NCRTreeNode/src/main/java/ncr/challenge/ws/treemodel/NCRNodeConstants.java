package ncr.challenge.ws.treemodel;

public interface NCRNodeConstants {
	public static String PARENET_NAME_CAN_NOT_BE_NULL = "parentN1ame can not be null";
	public static String NO_PARENT = "noParent";
	public static String ROOT_NODE_NAME = "root";
	public static String CHILD_NODE_DESC = "A child node";
	public static String ROOT_DESC = "A Root Desc";
	public static String NUMBER_OF_CHILDREN_EXCEEDED = "Num of children exceeded";
	public static String NODE_NAME_CAN_NOT_BE_NULL = "NodeName can not be null";
	public static String NODE_CAN_NOT_BE_NULL = "Node can not be null";
	public static String ROOT_NODE_CREATED = "Root Node Created";
	public static String CAN_NOT_REMOVE_ROOT_NODE = "Can not remove root node";

	public static final String FIND_BY_NODE_NAME_QUERY = "SELECT NODE_NAME, NODE_DESC, PARENT_NODE_NAME "
			+ "FROM NCR_NODE WHERE NODE_NAME = :nodeName";

	public final static String FIND_ANCESTORS_BY_NODE_NAME_QUERY = "WITH RECURSIVE EXPL ( NODE_NAME, NODE_DESC, PARENT_NODE_NAME) "
			+ "AS ( SELECT DISTINCT ROOT.NODE_NAME, ROOT.NODE_DESC, ROOT.PARENT_NODE_NAME "
			+ "FROM  NCR_NODE ROOT WHERE ROOT.NODE_NAME = :nodeName " + " UNION "
			+ "SELECT DISTINCT CHILD.NODE_NAME, CHILD.NODE_DESC, CHILD.PARENT_NODE_NAME "
			+ "FROM EXPL PARENT, NCR_NODE CHILD WHERE " + "PARENT.PARENT_NODE_NAME = CHILD.NODE_NAME) "
			+ "SELECT   DISTINCT PARENT_NODE_NAME, NODE_DESC, NODE_NAME "
			+ "FROM EXPL WHERE NODE_NAME <> :nodeName ORDER BY PARENT_NODE_NAME, NODE_NAME";

	public final static String FIND_ALL_CHLDREN_BY_NODE_NAME = "WITH RECURSIVE EXPL ( NODE_NAME, NODE_DESC, PARENT_NODE_NAME) "
			+ "AS ( SELECT DISTINCT ROOT.NODE_NAME, ROOT.NODE_DESC, ROOT.PARENT_NODE_NAME "
			+ "FROM  NCR_NODE ROOT WHERE ROOT.NODE_NAME = :nodeName " + " UNION "
			+ "SELECT DISTINCT CHILD.NODE_NAME, CHILD.NODE_DESC, CHILD.PARENT_NODE_NAME "
			+ "FROM EXPL PARENT, NCR_NODE CHILD WHERE " + " PARENT.NODE_NAME = CHILD.PARENT_NODE_NAME) "
			+ "SELECT DISTINCT NODE_NAME, NODE_DESC, PARENT_NODE_NAME " + "FROM EXPL WHERE NODE_NAME <> :nodeName "
			+ "ORDER BY PARENT_NODE_NAME, NODE_NAME";

	public final static String FIND_IMMEDIATE_CHLDREN_BY_NODE_NAME = "SELECT DISTINCT NODE_NAME, NODE_DESC, PARENT_NODE_NAME "
			+ "FROM NCR_NODE WHERE PARENT_NODE_NAME = :parentName " + " ORDER BY PARENT_NODE_NAME, NODE_NAME";
}
