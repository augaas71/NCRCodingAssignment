package ncr.challenge.ws.service;

import static ncr.challenge.ws.treemodel.NCRNodeConstants.FIND_ALL_CHLDREN_BY_NODE_NAME;
import static ncr.challenge.ws.treemodel.NCRNodeConstants.FIND_ANCESTORS_BY_NODE_NAME_QUERY;
import static ncr.challenge.ws.treemodel.NCRNodeConstants.FIND_BY_NODE_NAME_QUERY;
import static ncr.challenge.ws.treemodel.NCRNodeConstants.FIND_IMMEDIATE_CHLDREN_BY_NODE_NAME;
import static ncr.challenge.ws.treemodel.NCRNodeConstants.NODE_NAME_CAN_NOT_BE_NULL;
import static ncr.challenge.ws.treemodel.NCRNodeConstants.NUMBER_OF_CHILDREN_EXCEEDED;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import ncr.challenge.exceptions.NCTreeNodeOperationException;
import ncr.challenge.ws.treemodel.NCRNode;

@Service
public class NCRTreeServiceBean implements NCRTreeService {

	@PersistenceContext
	private EntityManager em;

	private static Logger logger = LogManager.getLogger("NCRTreeServiceBean.class");
	
	@Override
	public NCRNode getNCRNode(String nodeName) throws NCTreeNodeOperationException {
		NCRNode node = null;
		if (nodeName == null) {
			throw new NCTreeNodeOperationException(NODE_NAME_CAN_NOT_BE_NULL);
		}

		Query query = em.createNativeQuery(FIND_BY_NODE_NAME_QUERY, NCRNode.class).setParameter("nodeName",
					nodeName);
		node = (NCRNode) query.getSingleResult();
		
		return node;
	}

	@Override
	@Transactional
	public NCRNode createNode(NCRNode node) throws NCTreeNodeOperationException {
		if (node == null) {
			throw new NCTreeNodeOperationException("Nod Can not be null");
		}
		List<NCRNode> nodeList = getImmediateChildrenOfNode(node.getParentNodeName());
		logger.info(" Creating NCRNode " + node.getNodeName() + " " + " Size:" + nodeList.size());
		// check if node has less than 15 node
		if (nodeList.size() < 15) {
			em.persist(node);
		} else {
			throw new NCTreeNodeOperationException(NUMBER_OF_CHILDREN_EXCEEDED);
		}
		return node;
	}

	@Override
	@Transactional
	public NCRNode deleteNode(String nodeName) throws NCTreeNodeOperationException {
		if (nodeName == null) {
			throw new NCTreeNodeOperationException(NODE_NAME_CAN_NOT_BE_NULL);
		}

		NCRNode node = getNCRNode(nodeName);
		// remove children first
		List<NCRNode> nodeList = getAllChildrenOfNode(nodeName);
		if (!nodeList.isEmpty()) {
			for (NCRNode n : nodeList) {
				em.remove(n);
			}
		}

		// remove node
		em.remove(node);
		return node;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<NCRNode> getNodeAncestors(String nodeName) throws NCTreeNodeOperationException {

		if (nodeName == null) {
			throw new NCTreeNodeOperationException(NODE_NAME_CAN_NOT_BE_NULL);
		}
		List<NCRNode> nodes = null;

		Query query = em.createNativeQuery(FIND_ANCESTORS_BY_NODE_NAME_QUERY, NCRNode.class).setParameter("nodeName",
				nodeName);
		nodes = query.getResultList();
		return nodes;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<NCRNode> getImmediateChildrenOfNode(String nodeName) throws NCTreeNodeOperationException {
		if (nodeName == null) {
			throw new NCTreeNodeOperationException(NODE_NAME_CAN_NOT_BE_NULL);
		}
		Query query = em.createNativeQuery(FIND_IMMEDIATE_CHLDREN_BY_NODE_NAME, NCRNode.class)
				.setParameter("parentName", nodeName);
		List<NCRNode> nodes = query.getResultList();
		return nodes;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<NCRNode> getAllChildrenOfNode(String nodeName) throws NCTreeNodeOperationException {
		if (nodeName == null) {
			throw new NCTreeNodeOperationException(NODE_NAME_CAN_NOT_BE_NULL);
		}
		Query query = em.createNativeQuery(FIND_ALL_CHLDREN_BY_NODE_NAME, NCRNode.class).setParameter("nodeName",
				nodeName);
		List<NCRNode> nodes = query.getResultList();
		return nodes;
	}
}
