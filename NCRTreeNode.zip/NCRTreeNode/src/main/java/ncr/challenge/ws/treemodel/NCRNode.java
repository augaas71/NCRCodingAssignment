package ncr.challenge.ws.treemodel;

import static ncr.challenge.ws.treemodel.NCRNodeConstants.PARENET_NAME_CAN_NOT_BE_NULL;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import ncr.challenge.exceptions.NCTreeNodeOperationException;

@Entity
@Table(name = "NCR_NODE")
public class NCRNode {

	@Id
	@Column(name = "NODE_NAME")
	private String nodeName;

	@Column(name = "NODE_DESC")
	private String desc;

	@Column(name = "PARENT_NODE_NAME")
	private String parentNodeName;

	public String getNodeName() {
		return nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getParentNodeName() {
		return parentNodeName;
	}

	public void setParentNodeName(String parentNodeName) {
		this.parentNodeName = parentNodeName;
	}

	public NCRNode() {
	}

	public NCRNode(String nodeName) throws NCTreeNodeOperationException {
		if (nodeName == null) {
			throw new NCTreeNodeOperationException(PARENET_NAME_CAN_NOT_BE_NULL);
		} else if (nodeName.equals("root")) {
			this.desc = "A Root Node Desc";
		} else {
			this.desc = "A Child Node Desc";

		}
		this.nodeName = nodeName;
		this.parentNodeName = "noParent";
	}

	public NCRNode(String nodeName, String desc) throws NCTreeNodeOperationException {
		if (nodeName == null) {
			throw new NCTreeNodeOperationException(PARENET_NAME_CAN_NOT_BE_NULL);
		}
		this.nodeName = nodeName;
		this.desc = desc;
		this.parentNodeName = "noParent";
	}

	public NCRNode(String nodeName, String desc, String parentNode) throws NCTreeNodeOperationException {
		if (nodeName == null) {
			throw new NCTreeNodeOperationException(PARENET_NAME_CAN_NOT_BE_NULL);
		}
		this.nodeName = nodeName;
		this.desc = desc;
		this.parentNodeName = "noParent";
	}

}
