package ncr.challenge.ws.web.api;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import ncr.challenge.exceptions.NCTreeNodeOperationException;
import ncr.challenge.ws.service.NCRTreeService;
import ncr.challenge.ws.treemodel.NCRNode;
import ncr.challenge.ws.treemodel.NCRTree;

@RestController
public class NCRTReeController {

	@Autowired
	NCRTreeService treeService;

	static private NCRTree tree;

	private static Logger logger = LogManager.getLogger("NCRTReeController.class");

	static {
		logger.info("Creating Tree and intializing with the root node");
		try {
			setTree(new NCRTree());
		} catch (NCTreeNodeOperationException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

	@ExceptionHandler
	void handleIllegalArgumentException(NCTreeNodeOperationException e, HttpServletResponse response)
			throws IOException {
		response.sendError(HttpStatus.BAD_REQUEST.value());
	}

	@RequestMapping(value = "/api/tree", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<NCRNode> addNCRNode(@RequestBody NCRNode node) throws NCTreeNodeOperationException {
		logger.info(" addNCRNode  Started Creating NCRNode " + node.getNodeName() + " " + node.getDesc() + " " + node);
		NCRNode addedNode = treeService.createNode(node);
		return new ResponseEntity<NCRNode>(addedNode, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/api/tree/{nodeName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<NCRNode> getNCRNode(@PathVariable("nodeName") String nodeName)
			throws NCTreeNodeOperationException {
		logger.info(" getNCRNode  Started Fetching NCRNode " + nodeName);
		NCRNode node = treeService.getNCRNode(nodeName);

		return new ResponseEntity<NCRNode>(node, HttpStatus.OK);
	}

	@RequestMapping(value = "/api/tree/{nodeName}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<NCRNode> removeNCRNode(@PathVariable("nodeName") String nodeName)
			throws NCTreeNodeOperationException {
		logger.info(" removeNCRNode  Started Removing NCRNode " + nodeName);

		NCRNode node = treeService.deleteNode(nodeName);
		return new ResponseEntity<NCRNode>(node, HttpStatus.OK);
	}

	@RequestMapping(value = "/api/tree/{nodeName}/{type}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<NCRNode>> getNCRChildren(@PathVariable("nodeName") String nodeName,
			@PathVariable("type") String type) throws NCTreeNodeOperationException {
		logger.info(" getNCRChildren(...)  Started Fetching NCRNode's Children ( Both Immediate and ALL " + nodeName);
		List<NCRNode> nodeList = null;
		if (type.equals("AC")) {
			nodeList = treeService.getAllChildrenOfNode(nodeName);
		} else if (type.equals("IC")) {
			nodeList = treeService.getImmediateChildrenOfNode(nodeName);
		}

		return new ResponseEntity<List<NCRNode>>(nodeList, HttpStatus.OK);
	}

	@RequestMapping(value = "/api/tree/ancestors/{nodeName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<NCRNode>> getNCRNodeAncestors(@PathVariable("nodeName") String nodeName)
			throws NCTreeNodeOperationException {
		logger.info(" getNCRNodeAncestors(...)  Started Fetching NCRNode's Ancestors " + nodeName);
		List<NCRNode> ancestorList = treeService.getNodeAncestors(nodeName);

		return new ResponseEntity<List<NCRNode>>(ancestorList, HttpStatus.OK);
	}

	public static NCRTree getTree() {
		return tree;
	}

	public static void setTree(NCRTree tree) {
		NCRTReeController.tree = tree;
	}
}
