package ncr.challenge.ws.service;

import java.util.List;

import ncr.challenge.exceptions.NCTreeNodeOperationException;
import ncr.challenge.ws.treemodel.NCRNode;

public interface NCRTreeService {
	NCRNode createNode(NCRNode node) throws NCTreeNodeOperationException;
	NCRNode getNCRNode(String nodeName) throws NCTreeNodeOperationException;
	NCRNode deleteNode(String nodeName) throws NCTreeNodeOperationException;
	List<NCRNode> getImmediateChildrenOfNode(String nodeName) throws NCTreeNodeOperationException;
	List<NCRNode> getAllChildrenOfNode(String nodeName) throws NCTreeNodeOperationException;
	List<NCRNode> getNodeAncestors(String node) throws NCTreeNodeOperationException;
}
