package ncr.challenge.ws.treemodel;

import static ncr.challenge.ws.treemodel.NCRNodeConstants.ROOT_NODE_CREATED;
import static ncr.challenge.ws.treemodel.NCRNodeConstants.ROOT_NODE_NAME;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import ncr.challenge.exceptions.NCTreeNodeOperationException;

public class NCRTree {
	private final NCRNode rootNode;
	private static Logger logger = LogManager.getLogger("NCRTree.class");

	public NCRTree() throws NCTreeNodeOperationException {
		logger.info("Started Creating Root Node .....");
		rootNode = new NCRNode(ROOT_NODE_NAME);
		System.out.println(ROOT_NODE_CREATED);
	}

	public NCRNode getRootNode() {
		logger.info("Retrieved Root Node .....");
		return rootNode;
	}
}
