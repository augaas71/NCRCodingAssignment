package ncr.challenge.exceptions;

public class NCRChildNodeMaxException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6386814205942175396L;

	public NCRChildNodeMaxException(String exc) {
		super(exc);
	}

	public String getMessage() {
		return super.getMessage();
	}
}
