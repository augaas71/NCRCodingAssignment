package ncr.challenge.exceptions;

public class NCTreeNodeOperationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2773336476343259803L;

	public NCTreeNodeOperationException(String exc) {
		super(exc);
	}

	public String getMessage() {
		return super.getMessage();
	}
}
